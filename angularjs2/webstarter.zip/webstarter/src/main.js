require('./main.less')

var index = require('./pages/index.html')

document.body.innerHTML = index

console.log('main 223')