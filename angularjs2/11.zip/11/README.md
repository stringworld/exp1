## ToG项目开发说明

1. 安装依赖

    ```bash
    npm i
    ```

1. 开发模式

    ```bash
    npm run server
    ```

1. 构建

    ```bash
    npm run build
    ```