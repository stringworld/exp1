"use strict";
define(["main-app"], function (app) {
    //空
    app.controller("NoneController", ["$scope", function ($scope) {

    }]);
});