# Contributing to iScroll / FAQ

You are very welcome to collaborate, all changes to the code will be released under an MIT license.

By submitting a pull request you implicitly agree to give rights of your code to the project authors. Your contribution will always be released under the same MIT license.
