"use strict";
define(["main-app", "jquery", "tools"
], function (app, $, tools) {
  app.controller("SearchUserCtrl", ["$scope", "$location", "$timeout", "$q", "http", "storage", "scroll",
    function ($scope, $location, $timeout, $q, http, storage, scroll) {

    }
  ]);
});