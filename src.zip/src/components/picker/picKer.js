import angular from 'angular';

import './css/mobiscroll.custom-3.0.0-beta6.min.css';
import './js/mobiscroll.custom-3.0.0-beta6.min.js';

import './css/public.css';
import './css/sui.css';

import store from 'storejs';

export default angular.module("picKer", ['mobiscroll-select'])
    .directive('picKer', [function() {
        return {
            restrict: 'AE',
            scope: { showdata: '=', getchangedata: '&', closepicker: '&' },
            template: require('./picKer.html'),
            replace: false,
            controller: function($scope) {
                $scope.demoShow = function() {
                    $scope.demo.show();
                }
                $scope.settings = {
                    theme: 'ios',
                    lang: 'zh',
                    display: 'bottom',
                    circular: false,
                    label: 'Country',
                    group: true,
                    groupLabel: 'City',
                    width: [200, 200],
                    onSet: function(event, inst) {
                        var arr = inst._tempWheelArray,
                            settings = inst.settings,
                            thisId;
                        console.log(settings)
                        console.log(arr)
                        arr.forEach((i) => {
                            thisId = $scope.showdata.list.filter((item) => item.name === i).map((item) => item.id);
                        })
                        $scope.getchangedata({ id: thisId, name: arr })
                        $scope.closepicker();
                    },
                    onCancel: function(event, inst) {
                        var arr = inst._tempWheelArray,
                            settings = inst.settings;
                        console.log(arr, settings)
                    }

                };

                $scope.isShow = true;

                $scope.$watch('showdata.list', function() {
                    if ($scope.showdata.list[0]) {
                        if ($scope.showdata.list[0].list[0]) {
                            $scope.isShow = false;
                        } else {
                            $scope.isShow = true;
                        }
                        console.log($scope.showdata.list)
                        $scope.lists = $scope.showdata.list;
                        // [
                        //     { name: 'black', shade: 'dark' },
                        //     { name: 'white', shade: 'light' },
                        //     { name: 'red', shade: 'dark' },
                        //     { name: 'blue', shade: 'dark' },
                        //     { name: 'yellow', shade: 'light' }
                        // ];
                        setTimeout(function() {
                            $scope.demo.show();
                        }, 1000);
                    }
                    // $scope.settings.onSet = function(event, inst) {
                    //     var arr = inst._tempWheelArray,
                    //         settings = inst.settings;
                    //     console.log(settings)
                    //     console.log(arr)
                    //     var thisId = $scope.showdata.list.filter((item) => item.name === arr[0]).map((item) => item.id)[0];
                    //     $scope.getchangedata({ id: thisId, name: arr })
                    // }
                    $scope.settings.onCancel = function(event, inst) {
                        var arr = inst._tempWheelArray,
                            settings = inst.settings;
                        console.log(arr, settings)
                    }

                })
            },
            link: function(scope, element, attrs) {

            }
        };
    }])
    .name;