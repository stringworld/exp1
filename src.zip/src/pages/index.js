import page1Router from './page1/page1.route';
import basicRouter from './basic/basic.route';
import basicsRouter from './basics/basics.route';

let routes = [page1Router, basicRouter, basicsRouter]
export default routes

// export default angular.module('app', [uirouter, routerextras,page1])