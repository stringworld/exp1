
export default angular.module('page2', [])

  
  .name;