import page1Router from './page1/page1.route';
import page2Router from './page2/page2.route';

let routes=[page1Router,page2Router]
export default routes

// export default angular.module('app', [uirouter, routerextras,page1])
 