This is a demo for hybrid

npm run server  进入开发模式

npm run build 生产环境