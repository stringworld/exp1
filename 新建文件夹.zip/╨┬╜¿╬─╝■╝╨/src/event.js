/**
 * Created by zhouhua on 2016/12/21.
 */
import Vue from 'vue';

export default new Vue();
