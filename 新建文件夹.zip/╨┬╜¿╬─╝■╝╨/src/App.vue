<template>
    <div id="app">
        <transition name="slide"
                    :enter-active-class="enterActiveClass">
            <keep-alive>
                <router-view class="page"></router-view>
            </keep-alive>
        </transition>
    </div>
</template>

<script type="text/javascript">
    export default {
        data() {
            return {
                enterActiveClass: 'animated fadeIn'
            };
        },
        watch: {
            '$route' (to, from) {
                // todo
            }
        }
    }
</script>

<style lang="less" rel="stylesheet/less">
    html, body {
        width: 100%;
        height: 100%;
        min-height: 100%;
        padding: 0;
    }

    *,
    *:before,
    *:after {
        box-sizing: border-box;
    }

    input:focus {
        outline: none;
    }

    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        min-height: 100%;
        height: 100%;
    }

    .page {
        min-height: 100%;
        height: 100%;
    }

</style>
