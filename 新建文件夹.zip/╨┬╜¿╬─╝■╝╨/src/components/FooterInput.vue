<template>
    <footer>
        <input v-model="msg"/>
        <button @click="send">发送</button>
    </footer>
</template>
<style lang="less" scoped>
    footer{
        position: fixed;
        bottom: 0;
        left: 0;
        padding: 5px;
        border-top: thin solid #ddd;
        background: #fafafa;
        width: 100%;
        display: flex;
        flex: 1;
        flex-direction: row;
        input {
            height: 32px;
            line-height: 32px;
            border: thin solid #ccc;
            background: #fff;
            font-size: 14px;
            border-radius: 4px;
            padding: 0 8px;
            flex: auto;
        }
        button{
            width: 60px;
            height: 32px;
            line-height: 32px;
            padding: 0;
            border-radius: 4px;
            border: thin solid #ccc;
            background: #fff;
            margin-left: 10px;
            font-size: 16px;
        }
    }
</style>
<script>
    export default{
        data(){
            return{
                msg:'hello vue'
            }
        },
        methods: {
            send(){
            }
        }
    }
</script>
