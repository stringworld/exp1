<template>
    <section class="message" :class="[msg.type]">
        <img :src="msg.user.avatar" alt="" class="avatar">
        <h6>{{msg.user.name}}</h6>
        <div class="content">
            <slot></slot>
        </div>
    </section>
</template>

<style scoped lang="less">
    .message{
        width: 100%;
        overflow: hidden;
        position: relative;
        .avatar{
            position: absolute;
            top: 0;
            width: 36px;
            height: 36px;
        }
        h6{
            font-size: 12px;
            font-weight: normal;
            line-height: 16px;
            margin: 0;
        }
        .content{
            max-width: 80%;
            min-width: 48px;
            padding: 5px 6px;
            line-height: 20px;
            font-size: 14px;
            border: thin solid #ddd;
            border-radius: 4px;
            position: relative;
            &:before{
                position: absolute;
                content: '';
                top: 10px;
                width: 8px;
                height: 8px;
                transform: rotate(45deg);
                border: thin solid #ddd;
            }
        }
        &.receive{
            padding: 0 10px 20px 56px;
            .avatar{
                left: 10px;
            }
            .content{
                float: left;
                background: #fff;
                &:before{
                    border-width: 0 0 thin thin;
                    left: -5px;
                    background: #fff;
                }
            }
        }
        &.send{
            padding: 0 56px 20px 10px;
            .avatar{
                right: 10px;
            }
            h6{
                text-align: right;
            }
            .content{
                float: right;
                background: #A2E563;
                &:before{
                    border-width: thin thin 0 0;
                    right: -5px;
                    background: #A2E563;
                }
            }
        }
    }

</style>

<script>
    export default {
        name: 'message',
        props: ['msg'],
        data: function(){
            return {}
        }
    }
</script>
