/**
 * Created by zhouhua on 2016/12/20.
 */
import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

import One from '../views/One';
import Two from '../views/Two';
import bindPhoneNum from '../views/bindPhoneNum/bindPhoneNum';

export default new Router({
    routes: [{
            path: '/',
            redirect: '/one'
        },
        {
            path: '/one',
            component: One
        },
        {
            path: '/one/two',
            component: Two
        },
        {
            path: '/bindphonenum',
            component: bindPhoneNum
        }
    ]
});