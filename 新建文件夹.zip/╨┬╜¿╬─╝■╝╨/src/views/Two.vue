<template>
    <section class="page-one">
        <h1>{{title}}</h1>
        <a @click="back">back</a>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">
</style>
<script type="text/javascript">
    import router from 'src/routes';
    export default{
        data(){
            return {
                title: 'Page 2'
            }
        },
        methods: {
            back(){
                router.back();
            }
        }
    }

</script>
