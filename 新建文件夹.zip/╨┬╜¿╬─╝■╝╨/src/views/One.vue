<template>
    <section class="page-one">
        <h1>{{title}}</h1>
        <router-link to="/one/two">Go to Page 2</router-link>
        <div>
            <button @click="query">发起请求</button>
        </div>
        <p v-if="period" :class="className">这个请求花费了:{{period}}ms</p>
        <div>
            <child text="click" @oops="noticed"/>
        </div>
        <div>
            <another-child/>
        </div>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">
    button {
        border: #ccc thin solid;
    }

    .odd {
        color: palevioletred;
    }

    .even {
        color: blueviolet;
    }
</style>
<script type="text/javascript">
    import bus from '../event';
    const Child = {
        template: `<button @click="touched">{{text}}</button>`,
        props: {
            text: {
                type: String,
                required: false,
                default: 'click me'
            }
        },
        methods: {
            touched(){
                this.$emit('oops', 'touched the button');
                bus.$emit('globalTouch', new Date);
            }
        }
    }
    const AnotherChild = {
        data(){
            return {
                lastTouched: null,
                text: ''
            }
        },
        watch: {
            lastTouched(newValue){
                this.text = `The button was touched at ${newValue.toLocaleString()}`;
            }
        },
        mounted(){
            bus.$on('globalTouch', time => {
                this.lastTouched = time;
            });
        },
        render(h){
            return (
                <p> {this.lastTouched ? this.text : `havn't been touched.`}</p>
            )
        }
    }
    export default{
        components: {
            Child,
            AnotherChild
        },
        data(){
            return {
                title: 'Page 1',
                period: null
            }
        },
        computed: {
            className(){
                return this.period % 2 ? 'even' : 'odd';
            }
        },
        methods: {
            query(){
                let now = +new Date;
                this.$http.get('/test/get').then(({data}) => {
                    this.period = data.data - now;
                });
            },
            noticed(msg){
                alert(msg);
            }
        }
    }
</script>
