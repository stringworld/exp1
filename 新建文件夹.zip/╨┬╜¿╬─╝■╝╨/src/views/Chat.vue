<template>
    <div id="app">
        <message v-for="message in messages" :key="message.id" :msg="message">
            {{message.content}}
        </message>
        <footer-input/>
    </div>
</template>

<script type="text/javascript">
    import Message from './components/Message';
    import FooterInput from './components/FooterInput';
    export default {
        name: 'app',
        components: {
            Message,
            FooterInput
        },
        data: function () {
            return {
                messages: [
                    {
                        id: 0,
                        user: {
                            avatar: require('./assets/logo.png'),
                            name: 'medishare'
                        },
                        content: 'test ddfsdjkf fsdf fsdfsdf fsfddf werwer fx fsdfsfsf fsdf',
                        type: 'send'
                    },
                    {
                        id: 1,
                        user: {
                            avatar: require('./assets/logo.png'),
                            name: 'hospital'
                        },
                        content: 'answer',
                        type: 'receive'
                    }]
            };
        }
    }
</script>

<style lang="less" rel="stylesheet/less">
    html, body {
        width: 100%;
        height: 100%;
        min-height: 100%;
        padding: 0;
    }

    *,
    *:before,
    *:after {
        box-sizing: border-box;
    }

    input:focus {
        outline: none;
    }

    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }

</style>
