<template>
    <section class="bind-phone">
        <form>
            <div class="layout-default">
                <input type="number" class="phone" v-bind:placeholder="title" v-model="phone.mobile" @input="onInputMobile">
            </div>
            <div class="layout-default">
                <input type="number" class="verify-code" placeholder="请输入验证码" v-model="phone.code" @input="onInputCode">
                <span class="get-verify" v-bind:class="{checked:isActive}" @click="getVerify">{{verify.text}}</span>
            </div>
            <span class="layout-default mes mes-error">
                {{phone.mesError}}
            </span>
            <div class="layout-default bind-btn" v-bind:class="{checked:isCode&&verify.stop}" @click="bindPhoneNum">绑定</div>
            <span class="layout-default mes mes-default">
                绑定手机号有助于向您及时同步订单最新进度
            </span>
        </form>
    </section>
</template>
<style scoped lang="less">
    @import './bindPhoneNum.less';
</style>

<script type="text/javascript">
    var reg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
    var headers = {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    };
    export default {
        data() {
            return {
                phone: { mesError: '', mobile: null, code: null },
                isActive: false,
                isCode: false,
                title: '请输入手机号',
                verify: {
                    text: '获取验证码', //显示文本
                    timer: 60, //默认倒数30秒
                    stop: false,
                    Interval: null //setInterval的对象
                }
            }
        },
        methods: {
            update() {
                if (this.verify.timer <= 0) {
                    this.verify.timer = 60;
                    this.isActive = true;
                    this.verify.stop = false;
                    this.verify.text = '获取验证码';
                    clearInterval(this.verify.Interval);
                } else {
                    this.isActive = false;
                    this.verify.stop = true;
                    this.verify.timer = this.verify.timer - 1;
                    this.verify.text = this.verify.timer + '秒';
                }
            },
            onInputMobile() {
                if (!/^\d{11}$/.test(this.phone.mobile + '')) {
                    this.phone.mobile = (this.phone.mobile + '').slice(0, 11);
                }
                if (!reg.test(this.phone.mobile + '')) {
                    this.isActive = false;
                    this.phone.mesError = '请输入正确的手机号';
                } else {
                    this.isActive = true;
                    this.phone.mesError = '';
                }
            },
            onInputCode() {
                if (!/^\d{4}$/.test(this.phone.code + '')) {
                    this.phone.code = (this.phone.code + '').slice(0, 4);
                }
                if (this.phone.code != null && (this.phone.code + '').length === 4) {
                    this.isCode = true;
                    this.phone.mesError = '';
                } else {
                    this.isCode = false;
                    this.phone.mesError = '请输入正确的验证码';
                }
            },
            getVerify() {
                //如果是false就开始倒计时，如果是true就停止倒计时
                if (this.isActive) {
                    let config = {
                        mobile: this.phone.mobile
                    };
                    this.$http.post('/member/wxregistCode', config, headers).then(({ data }) => {
                        if (data.isSuccess) {
                            this.verify.Interval = setInterval(this.update, 1000);
                        }
                        console.log(data);
                    });
                }
            },
            bindPhoneNum() {
                if (this.isCode && this.verify.stop) {
                    let config = {
                        code: this.phone.code,
                    };
                    this.$http.post('/member/wxmemberRegister', config, headers).then(({ data }) => {
                        if (data.isSuccess) {
                            this.phone.mesError = '可以提交';
                        }
                        console.log(data);
                    });
                }
            }
        }
    }
</script>