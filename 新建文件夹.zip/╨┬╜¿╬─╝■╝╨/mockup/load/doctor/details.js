var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code":0,
        "serialID":null,
        "data":{
            "departmentName":"呼吸内科",
            "titleType":"主治医师",
            "doctorType":"全科医生",
            "countContracts":235,
            "address":"南京东路街道社区卫生服务中心",
            "isStar":true,
            "specials":[],
            "doctorId":"100369",
            "name":"周勇",
            "description":"相信我",
            "portrait":"http://upyun.thedoc.cn/cdn/addService/icon/zjdz_icon.jpg",
            "inService":true
        },
        "errorMsg":null,
        "pager":null
    })
}
module.exports = data;