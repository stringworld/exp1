var Mock = require('mockjs');
var data = function() {
    return Mock.mock({        
        "code":0,
        "data":{
            "id":"1",
            "description":"模拟：\n 你和他在一起\n测试:\n 你会后悔好哈模拟：\n 你和他在一起\n测试:\n 你会后悔好哈模拟：\n 你和他在一起\n测试:\n 你会后悔好哈模拟：\n 你和他在一起\n测试:\n 你会后悔好哈模拟：\n 你和他在一起\n测试:\n 你会后悔好哈",
            "caseLabelList":[
                {
                    "tagText":"检查化验类",
                    "imgUrl":"http://upyun.thedoc.cn/cdn/addService/icon/zjdz_icon.jpg"
                },
                {
                    "tagText":"病例资料类",
                    "imgUrl":"http://upyun.thedoc.cn/cdn/addService/icon/myzx_icon.png"
                },
                {
                    "tagText":"病例资料类",
                    "imgUrl":"http://upyun.thedoc.cn/cdn/addService/B2/zlnB2_img02.png"
                },
                {
                    "tagText":"病例资料类",
                    "imgUrl":"http://upyun.thedoc.cn/cdn/addService/icon/zjdz_icon.jpg"
                }
            ],
            "orderId":"103693"
        }        
    });
}
module.exports = data;