var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "isSuccess":true,
        "data":{
            "last":0,
            "count":8,
            "shareParms":"&isShare=true&shareUrl=http%3A%2F%2F192.168.10.214%2Fh5%2Factivity%2FaddService%2Fzjdz_B5.html%3Fid%3D100006%3FdotConstant%3Ddis_gp_Vas_d_expguid&shareTitle=%E4%B8%93%E5%AE%B6%E5%AF%BC%E8%AF%8A&shareContent=%E7%96%BE%E7%97%85%E7%AD%9B%E6%9F%A5++%E4%B8%93%E5%AE%B6%E8%AF%84%E4%BC%B0++%E7%B2%BE%E5%87%86%E6%9D%83%E5%A8%81++%E9%81%BF%E5%85%8D%E8%AF%AF%E8%AF%8A&shareIcon=http%3A%2F%2Fupyun.thedoc.cn%2Fcdn%2FaddService%2Ficon%2Fzjdz_icon.jpg",
            "title":"专家导诊",
            "userComments":[

            ],
            "priceText":"300元/次"
        },
        "type":"String"
    })
}
module.exports = data;