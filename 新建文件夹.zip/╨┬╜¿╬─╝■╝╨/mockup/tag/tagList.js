var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "type": "JSONDoctor",
        "data": {
            "tagList": [
                { name: '朋友1', id: 1, count: 5, disable: true, img: 'https://git.oschina.net/assets/no_portrait-95a1a012190f89ac0edc7253b34e99c1.png' },
                { name: '朋友2', id: 2, count: 1, disable: true, img: 'https://git.oschina.net/assets/no_portrait-95a1a012190f89ac0edc7253b34e99c1.png' },
                { name: '朋友3', id: 3, count: 2, disable: true, img: 'https://git.oschina.net/assets/no_portrait-95a1a012190f89ac0edc7253b34e99c1.png' },
            ]
        },
        "isSuccess": true
    })
}
module.exports = data;