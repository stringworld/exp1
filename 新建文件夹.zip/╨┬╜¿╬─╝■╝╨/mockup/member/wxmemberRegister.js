var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "type": "1",
        "errorMsg": "！"
    })
}
module.exports = data;