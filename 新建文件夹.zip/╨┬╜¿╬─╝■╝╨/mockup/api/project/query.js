var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [
            {"number": "1001", "name": "项目1", "content": "项目1"},
            {"number": "1002", "name": "项目2", "content": "项目2"
        }]
    })
}
module.exports = data;