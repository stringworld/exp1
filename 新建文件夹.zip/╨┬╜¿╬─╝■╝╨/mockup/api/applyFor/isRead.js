var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [
            {
                "created": 1480488153000,
                "disable": "0",
                "id": "100669",
                "isRead": "0",
                "managerId": "user0004",
                "note": "100",
                "updated": 1480488153000,
                "userId": "user0001"
            },{
                "created": 1480488153000,
                "disable": "0",
                "id": "100669",
                "isRead": "1",
                "managerId": "user0004",
                "note": "100",
                "updated": 1480488153000,
                "userId": "user0001"
            }
        ],
        "pager": {
            "count": 1,
            "current": 1,
            "hasNext": false,
            "pageSize": 10
        }
    })
}
module.exports = data;