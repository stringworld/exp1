var Mock = require('mockjs');
var data = function () {
    return Mock.mock({"code":1})
}
module.exports = data;