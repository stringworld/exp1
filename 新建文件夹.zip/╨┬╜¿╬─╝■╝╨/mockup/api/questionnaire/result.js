var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
            "code": 0,
            "errorMsg": '123',
            // "data": [{
            //     "questionId": "100665",
            //     "questionNumber": "Q1",
            //     "items": [{"key": "1", "value": "否"}]
            // }, {
            //     "questionId": "100666",
            //     "questionNumber": "Q2",
            //     "items": [{"key": "2", "value": "是"}]
            // }, {
            //     "questionId": "100667",
            //     "questionNumber": "Q3",
            //     "items": [{"key": "1", "value": "否"}]
            // }, {
            //     "questionId": "100668",
            //     "questionNumber": "Q4",
            //     "items": [{"key": "3", "value": "满意"}]
            // }, {
            //     "questionId": "100669",
            //     "questionNumber": "Q5",
            //     "items": [{"key": "4", "value": "药品种类少"}]
            // }, {
            //     "questionId": "100670",
            //     "questionNumber": "Q6",
            //     "items": [{"key": "5", "value": "文盲及半文盲"}]
            // }]
        }
    )
}
module.exports = data;