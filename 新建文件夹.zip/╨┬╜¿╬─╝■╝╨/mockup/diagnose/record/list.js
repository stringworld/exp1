var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code":0,
        "orderId":"103693",
        "data":[
            {
                "date":"1288323623006",
                "id": '1',
                "message": "已完成上门服务",
                "status": "read",
                "type":"visiting"
            },
            {
                "date":"1478770414000",
                "id": '2',
                "message": "已完成电话随访服务",
                "status": "write",
                "type":"tel"
            },
            {
                "date":"1478770562389",
                "id": '3',
                "message": "已完成电话随访服务",
                "status": "write",
                "type":"tel"
            },
            {
                "date":"1478770419753",
                "id": '4',
                "message": "已完成上门服务",
                "status": "write",
                "type":"visiting"
            }
        ]     
    })
}
module.exports = data;