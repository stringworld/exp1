var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "data": {
            "hospitalAttributeList": [{
                    "hospitalAttributeId": "1",
                    "hospitalAttributeName": "公立"
                },
                {
                    "hospitalAttributeId": "2",
                    "hospitalAttributeName": "民营"
                },
                {
                    "hospitalAttributeId": "3",
                    "hospitalAttributeName": "外资"
                }
            ],
            "specialtyList": [{
                    "subSpecialtyList": [{
                            "id": "500",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "冠心病",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1023",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "房颤",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1024",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心绞痛",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1025",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心肌梗死",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1026",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心肌缺血",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1027",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "高血压",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1028",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心律失常",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1029",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "短暂性脑缺血发作",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1030",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑梗死",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1031",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑出血",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1032",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "偏头痛",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1033",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "蛛网膜下腔出血",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1034",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "癫痫",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1035",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性阻塞性肺疾病",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1036",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "哮喘",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1037",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性咽炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1038",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性支气管炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1039",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肺炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1040",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "过敏性鼻炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1041",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "上呼吸道感染",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1042",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性胃炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1043",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "消化性溃疡",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1044",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性肠炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1045",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肝硬化",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1046",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脂肪肝",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1047",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性胰腺炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1048",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "慢性胆囊炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1049",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "糖尿病",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1050",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "甲亢",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1051",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "甲减",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1052",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "高脂血症",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1053",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "痛风",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1054",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "骨质疏松",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1055",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "内分泌失调",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1056",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "关节炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1057",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "尿路感染",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1058",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肾炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1059",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肾功能不全",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1060",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "红斑狼疮",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1061",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "贫血",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1062",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "皮肤过敏",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1063",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "紫癜",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1064",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肺癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1065",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "胃癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1066",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肝癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1067",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "胰腺癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1068",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "乳腺癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1069",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "前列腺癌",
                            "description": "",
                            "tags": "",
                            "path": "0,1001"
                        },
                        {
                            "id": "1132",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心肌梗塞",
                            "description": "运营导入"
                        },
                        {
                            "id": "1133",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心力衰竭",
                            "description": "运营导入"
                        },
                        {
                            "id": "1134",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "心脏病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1135",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "胃食管反流性疾病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1136",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "上消化道出血",
                            "description": "运营导入"
                        },
                        {
                            "id": "1137",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "面瘫",
                            "description": "运营导入"
                        },
                        {
                            "id": "1138",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "帕金森",
                            "description": "运营导入"
                        },
                        {
                            "id": "1139",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑血管意外",
                            "description": "运营导入"
                        },
                        {
                            "id": "1140",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑梗赛",
                            "description": "运营导入"
                        },
                        {
                            "id": "1141",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "失眠",
                            "description": "运营导入"
                        },
                        {
                            "id": "1142",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "头晕",
                            "description": "运营导入"
                        },
                        {
                            "id": "1143",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "头痛",
                            "description": "运营导入"
                        },
                        {
                            "id": "1144",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑动脉供血不足",
                            "description": "运营导入"
                        },
                        {
                            "id": "1145",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "记忆障碍",
                            "description": "运营导入"
                        },
                        {
                            "id": "1146",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "睡眠障碍",
                            "description": "运营导入"
                        },
                        {
                            "id": "1147",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "脑卒中",
                            "description": "运营导入"
                        },
                        {
                            "id": "1148",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "中风",
                            "description": "运营导入"
                        },
                        {
                            "id": "1149",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "前列腺增生",
                            "description": "运营导入"
                        },
                        {
                            "id": "1150",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "前列腺炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1151",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肾功能衰竭",
                            "description": "运营导入"
                        },
                        {
                            "id": "1152",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肾病综合征",
                            "description": "运营导入"
                        },
                        {
                            "id": "1153",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "尿潴留",
                            "description": "运营导入"
                        },
                        {
                            "id": "1154",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "尿失禁",
                            "description": "运营导入"
                        },
                        {
                            "id": "1155",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "甲状腺结节",
                            "description": "运营导入"
                        },
                        {
                            "id": "1156",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "肥胖症",
                            "description": "运营导入"
                        },
                        {
                            "id": "1157",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "代谢综合征",
                            "description": "运营导入"
                        },
                        {
                            "id": "1158",
                            "layer": 2,
                            "parentId": "1001",
                            "name": "垂体-肾上腺疾病",
                            "description": "运营导入"
                        }
                    ],
                    "name": "内科",
                    "id": "1001"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1070",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "丹毒",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1071",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "淋巴结炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1072",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "甲沟炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1073",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "甲状腺腺瘤",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1074",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "乳腺炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1075",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "乳腺增生",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1076",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "胆石病",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1077",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "痔疮",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1078",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "静脉曲张",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1079",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "脉管炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1080",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "尿石症",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1081",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "前列腺炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1082",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "前列腺增生",
                            "description": "",
                            "tags": "",
                            "path": "0,1002"
                        },
                        {
                            "id": "1159",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "灼伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1160",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "电击伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1161",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "热挤压伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1162",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "呼吸道烧伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1163",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "大面积烧伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1164",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "颅脑外伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1165",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "周围神经损伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1166",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肩周炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1167",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "多发伤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1168",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "骨质疏松",
                            "description": "运营导入"
                        },
                        {
                            "id": "1169",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "骨折",
                            "description": "运营导入"
                        },
                        {
                            "id": "1170",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肛瘘",
                            "description": "运营导入"
                        },
                        {
                            "id": "1171",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "便秘",
                            "description": "运营导入"
                        },
                        {
                            "id": "1172",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肛周脓肿",
                            "description": "运营导入"
                        },
                        {
                            "id": "1173",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "酒精性肝病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1174",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肝癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1175",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "脂肪肝",
                            "description": "运营导入"
                        },
                        {
                            "id": "1176",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肝炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1177",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "疝",
                            "description": "运营导入"
                        },
                        {
                            "id": "1178",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "胆囊炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1179",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "胰腺炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1180",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "结肠癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1181",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "甲状腺癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1182",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "胃癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1183",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "结肠炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1184",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "急性呼吸窘迫综合征",
                            "description": "运营导入"
                        },
                        {
                            "id": "1185",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "重症感染",
                            "description": "运营导入"
                        },
                        {
                            "id": "1186",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "脓毒症",
                            "description": "运营导入"
                        },
                        {
                            "id": "1187",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "多器官功能衰竭",
                            "description": "运营导入"
                        },
                        {
                            "id": "1188",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "颈椎病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1189",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "腰椎病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1190",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "食管癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1191",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "气胸",
                            "description": "运营导入"
                        },
                        {
                            "id": "1192",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肺部结节",
                            "description": "运营导入"
                        },
                        {
                            "id": "1193",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肺气肿",
                            "description": "运营导入"
                        },
                        {
                            "id": "1194",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "肺大泡",
                            "description": "运营导入"
                        },
                        {
                            "id": "1195",
                            "layer": 2,
                            "parentId": "1002",
                            "name": "重症肌无力",
                            "description": "运营导入"
                        }
                    ],
                    "name": "外科",
                    "id": "1002"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1083",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "阴道炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        },
                        {
                            "id": "1084",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "宫颈炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        },
                        {
                            "id": "1085",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "盆腔炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        },
                        {
                            "id": "1086",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "痛经",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        },
                        {
                            "id": "1087",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "绝经综合征",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        },
                        {
                            "id": "1088",
                            "layer": 2,
                            "parentId": "1003",
                            "name": "月经病",
                            "description": "",
                            "tags": "",
                            "path": "0,1003"
                        }
                    ],
                    "name": "妇科",
                    "id": "1003"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1089",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿腹泻",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1090",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿上呼吸道感染",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1091",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿手足口病",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1092",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿风疹",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1093",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿发热",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1094",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿咳嗽",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1095",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿感冒",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1096",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿哮喘",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1097",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿肥胖",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1098",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "小儿维生素D缺乏症",
                            "description": "",
                            "tags": "",
                            "path": "0,1004"
                        },
                        {
                            "id": "1207",
                            "layer": 2,
                            "parentId": "1004",
                            "name": "儿童弱视",
                            "description": "运营导入"
                        }
                    ],
                    "name": "儿科",
                    "id": "1004"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1099",
                            "layer": 2,
                            "parentId": "1005",
                            "name": "骨关节炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1005"
                        },
                        {
                            "id": "1100",
                            "layer": 2,
                            "parentId": "1005",
                            "name": "颈椎病",
                            "description": "",
                            "tags": "",
                            "path": "0,1005"
                        },
                        {
                            "id": "1101",
                            "layer": 2,
                            "parentId": "1005",
                            "name": "腰椎间盘突出症",
                            "description": "",
                            "tags": "",
                            "path": "0,1005"
                        }
                    ],
                    "name": "骨科",
                    "id": "1005"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1102",
                        "layer": 2,
                        "parentId": "1006",
                        "name": "中医",
                        "description": "",
                        "tags": "",
                        "path": "0,1006"
                    }],
                    "name": "中医科",
                    "id": "1006"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1103",
                        "layer": 2,
                        "parentId": "1007",
                        "name": "针灸",
                        "description": "",
                        "tags": "",
                        "path": "0,1007"
                    }],
                    "name": "针灸科",
                    "id": "1007"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1104",
                        "layer": 2,
                        "parentId": "1008",
                        "name": "推拿",
                        "description": "",
                        "tags": "",
                        "path": "0,1008"
                    }],
                    "name": "推拿科",
                    "id": "1008"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1105",
                            "layer": 2,
                            "parentId": "1009",
                            "name": "骨关节炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1009"
                        },
                        {
                            "id": "1106",
                            "layer": 2,
                            "parentId": "1009",
                            "name": "颈椎病",
                            "description": "",
                            "tags": "",
                            "path": "0,1009"
                        },
                        {
                            "id": "1107",
                            "layer": 2,
                            "parentId": "1009",
                            "name": "腰椎间盘突出症",
                            "description": "",
                            "tags": "",
                            "path": "0,1009"
                        }
                    ],
                    "name": "中医骨科",
                    "id": "1009"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1108",
                            "layer": 2,
                            "parentId": "1010",
                            "name": "中耳炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1010"
                        },
                        {
                            "id": "1109",
                            "layer": 2,
                            "parentId": "1010",
                            "name": "鼻炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1010"
                        },
                        {
                            "id": "1110",
                            "layer": 2,
                            "parentId": "1010",
                            "name": "鼻出血",
                            "description": "",
                            "tags": "",
                            "path": "0,1010"
                        },
                        {
                            "id": "1111",
                            "layer": 2,
                            "parentId": "1010",
                            "name": "扁桃体炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1010"
                        }
                    ],
                    "name": "耳鼻喉科",
                    "id": "1010"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1112",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "牙痛",
                            "description": "",
                            "tags": "",
                            "path": "0,1011"
                        },
                        {
                            "id": "1113",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "龋齿",
                            "description": "",
                            "tags": "",
                            "path": "0,1011"
                        },
                        {
                            "id": "1114",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "口腔溃疡",
                            "description": "",
                            "tags": "",
                            "path": "0,1011"
                        },
                        {
                            "id": "1208",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "牙齿畸形",
                            "description": "运营导入"
                        },
                        {
                            "id": "1209",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "错牙合",
                            "description": "运营导入"
                        },
                        {
                            "id": "1210",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "牙周炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1211",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "舌癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1212",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "口腔癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1213",
                            "layer": 2,
                            "parentId": "1011",
                            "name": "牙髓炎",
                            "description": "运营导入"
                        }
                    ],
                    "name": "口腔科",
                    "id": "1011"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1115",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "结膜炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1012"
                        },
                        {
                            "id": "1116",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "白内障",
                            "description": "",
                            "tags": "",
                            "path": "0,1012"
                        },
                        {
                            "id": "1117",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "青光眼",
                            "description": "",
                            "tags": "",
                            "path": "0,1012"
                        },
                        {
                            "id": "1214",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "干眼症",
                            "description": "运营导入"
                        },
                        {
                            "id": "1215",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "视网膜脱离",
                            "description": "运营导入"
                        },
                        {
                            "id": "1216",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "糖尿病眼病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1217",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "黄斑裂孔",
                            "description": "运营导入"
                        },
                        {
                            "id": "1218",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "倒睫",
                            "description": "运营导入"
                        },
                        {
                            "id": "1219",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "胬肉",
                            "description": "运营导入"
                        },
                        {
                            "id": "1220",
                            "layer": 2,
                            "parentId": "1012",
                            "name": "屈光不正",
                            "description": "运营导入"
                        }
                    ],
                    "name": "眼科",
                    "id": "1012"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1118",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "湿疹",
                            "description": "",
                            "tags": "",
                            "path": "0,1013"
                        },
                        {
                            "id": "1119",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "荨麻疹",
                            "description": "",
                            "tags": "",
                            "path": "0,1013"
                        },
                        {
                            "id": "1120",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "手足癣",
                            "description": "",
                            "tags": "",
                            "path": "0,1013"
                        },
                        {
                            "id": "1121",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "皮炎",
                            "description": "",
                            "tags": "",
                            "path": "0,1013"
                        },
                        {
                            "id": "1221",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "银屑病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1222",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "病毒疣",
                            "description": "运营导入"
                        },
                        {
                            "id": "1223",
                            "layer": 2,
                            "parentId": "1013",
                            "name": "皮肤美容",
                            "description": "运营导入"
                        }
                    ],
                    "name": "皮肤科",
                    "id": "1013"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1122",
                            "layer": 2,
                            "parentId": "1014",
                            "name": "儿童保健",
                            "description": "",
                            "tags": "",
                            "path": "0,1014"
                        },
                        {
                            "id": "1123",
                            "layer": 2,
                            "parentId": "1014",
                            "name": "小儿生长发育",
                            "description": "",
                            "tags": "",
                            "path": "0,1014"
                        }
                    ],
                    "name": "儿童保健科",
                    "id": "1014"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1124",
                        "layer": 2,
                        "parentId": "1015",
                        "name": "妇女保健",
                        "description": "",
                        "tags": "",
                        "path": "0,1015"
                    }],
                    "name": "妇女保健科",
                    "id": "1015"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1125",
                        "layer": 2,
                        "parentId": "1016",
                        "name": "预防保健",
                        "description": "",
                        "tags": "",
                        "path": "0,1016"
                    }],
                    "name": "预防保健科",
                    "id": "1016"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1126",
                        "layer": 2,
                        "parentId": "1017",
                        "name": "计划生育指导",
                        "description": "",
                        "tags": "",
                        "path": "0,1017"
                    }],
                    "name": "计划生育指导科",
                    "id": "1017"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1127",
                        "layer": 2,
                        "parentId": "1018",
                        "name": "慢病康复",
                        "description": "",
                        "tags": "",
                        "path": "0,1018"
                    }],
                    "name": "康复医疗科",
                    "id": "1018"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1128",
                        "layer": 2,
                        "parentId": "1019",
                        "name": "临终关怀",
                        "description": "",
                        "tags": "",
                        "path": "0,1019"
                    }],
                    "name": "临终关怀科",
                    "id": "1019"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1129",
                        "layer": 2,
                        "parentId": "1020",
                        "name": "老年护理",
                        "description": "",
                        "tags": "",
                        "path": "0,1020"
                    }],
                    "name": "老年护理科",
                    "id": "1020"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1130",
                        "layer": 2,
                        "parentId": "1021",
                        "name": "检查报告",
                        "description": "",
                        "tags": "",
                        "path": "0,1021"
                    }],
                    "name": "医技检查科",
                    "id": "1021"
                },
                {
                    "subSpecialtyList": [{
                        "id": "1131",
                        "layer": 2,
                        "parentId": "1022",
                        "name": "其他",
                        "description": "",
                        "tags": "",
                        "path": "0,1022"
                    }],
                    "name": "其他科室",
                    "id": "1022"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1197",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "宫颈癌",
                            "description": "运营导入"
                        },
                        {
                            "id": "1198",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "宫颈炎",
                            "description": "运营导入"
                        },
                        {
                            "id": "1199",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "妊娠期心脏病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1200",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "妊娠期高血压",
                            "description": "运营导入"
                        },
                        {
                            "id": "1201",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "妊娠期糖尿病",
                            "description": "运营导入"
                        },
                        {
                            "id": "1202",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "围绝经期综合征",
                            "description": "运营导入"
                        },
                        {
                            "id": "1203",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "更年期综合征",
                            "description": "运营导入"
                        },
                        {
                            "id": "1204",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "子宫肌瘤",
                            "description": "运营导入"
                        },
                        {
                            "id": "1205",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "月经不调",
                            "description": "运营导入"
                        },
                        {
                            "id": "1206",
                            "layer": 2,
                            "parentId": "1196",
                            "name": "多囊卵巢综合征",
                            "description": "运营导入"
                        }
                    ],
                    "name": "妇产科",
                    "id": "1196"
                },
                {
                    "subSpecialtyList": [{
                            "id": "1225",
                            "layer": 2,
                            "parentId": "1224",
                            "name": "阴茎发育不全",
                            "description": "运营导入"
                        },
                        {
                            "id": "1226",
                            "layer": 2,
                            "parentId": "1224",
                            "name": "精索静脉曲张",
                            "description": "运营导入"
                        },
                        {
                            "id": "1227",
                            "layer": 2,
                            "parentId": "1224",
                            "name": "男性精子活力低下",
                            "description": "运营导入"
                        },
                        {
                            "id": "1228",
                            "layer": 2,
                            "parentId": "1224",
                            "name": "性功能障碍",
                            "description": "运营导入"
                        },
                        {
                            "id": "1229",
                            "layer": 2,
                            "parentId": "1224",
                            "name": "不育症",
                            "description": "运营导入"
                        }
                    ],
                    "name": "男性科",
                    "id": "1224"
                }
            ],
            "hospitalLevelList": [{
                    "hospitalLevelId": "2",
                    "hospitalLevelName": "二级"
                },
                {
                    "hospitalLevelId": "3",
                    "hospitalLevelName": "三级"
                }
            ],
            "provinceListWithCity": [{
                    "name": "北京",
                    "id": "1",
                    "cityList": [{
                        "id": "1",
                        "name": "北京市",
                        "provinceId": "1"
                    }]
                },
                {
                    "name": "上海",
                    "id": "2",
                    "cityList": [{
                        "id": "75",
                        "name": "上海市",
                        "provinceId": "2"
                    }]
                },
                {
                    "name": "天津",
                    "id": "3",
                    "cityList": [{
                        "id": "3",
                        "name": "天津市",
                        "provinceId": "3"
                    }]
                },
                {
                    "name": "河北",
                    "id": "4",
                    "cityList": [{
                            "id": "5",
                            "name": "石家庄市",
                            "provinceId": "4"
                        },
                        {
                            "id": "6",
                            "name": "唐山市",
                            "provinceId": "4"
                        },
                        {
                            "id": "7",
                            "name": "秦皇岛市",
                            "provinceId": "4"
                        },
                        {
                            "id": "8",
                            "name": "邯郸市",
                            "provinceId": "4"
                        },
                        {
                            "id": "9",
                            "name": "邢台市",
                            "provinceId": "4"
                        },
                        {
                            "id": "10",
                            "name": "保定市",
                            "provinceId": "4"
                        },
                        {
                            "id": "11",
                            "name": "张家口市",
                            "provinceId": "4"
                        },
                        {
                            "id": "12",
                            "name": "承德市",
                            "provinceId": "4"
                        },
                        {
                            "id": "13",
                            "name": "沧州市",
                            "provinceId": "4"
                        },
                        {
                            "id": "14",
                            "name": "廊坊市",
                            "provinceId": "4"
                        },
                        {
                            "id": "15",
                            "name": "衡水市",
                            "provinceId": "4"
                        }
                    ]
                },
                {
                    "name": "内蒙古",
                    "id": "5",
                    "cityList": [{
                            "id": "27",
                            "name": "呼和浩特市",
                            "provinceId": "5"
                        },
                        {
                            "id": "28",
                            "name": "包头市",
                            "provinceId": "5"
                        },
                        {
                            "id": "29",
                            "name": "乌海市",
                            "provinceId": "5"
                        },
                        {
                            "id": "30",
                            "name": "赤峰市",
                            "provinceId": "5"
                        },
                        {
                            "id": "31",
                            "name": "通辽市",
                            "provinceId": "5"
                        },
                        {
                            "id": "32",
                            "name": "鄂尔多斯市",
                            "provinceId": "5"
                        },
                        {
                            "id": "33",
                            "name": "呼伦贝尔市",
                            "provinceId": "5"
                        },
                        {
                            "id": "34",
                            "name": "巴彦淖尔市",
                            "provinceId": "5"
                        },
                        {
                            "id": "35",
                            "name": "乌兰察布市",
                            "provinceId": "5"
                        },
                        {
                            "id": "36",
                            "name": "兴安盟",
                            "provinceId": "5"
                        },
                        {
                            "id": "37",
                            "name": "锡林郭勒盟",
                            "provinceId": "5"
                        },
                        {
                            "id": "38",
                            "name": "阿拉善盟",
                            "provinceId": "5"
                        }
                    ]
                },
                {
                    "name": "辽宁",
                    "id": "6",
                    "cityList": [{
                            "id": "39",
                            "name": "沈阳市",
                            "provinceId": "6"
                        },
                        {
                            "id": "40",
                            "name": "大连市",
                            "provinceId": "6"
                        },
                        {
                            "id": "41",
                            "name": "鞍山市",
                            "provinceId": "6"
                        },
                        {
                            "id": "42",
                            "name": "抚顺市",
                            "provinceId": "6"
                        },
                        {
                            "id": "43",
                            "name": "本溪市",
                            "provinceId": "6"
                        },
                        {
                            "id": "44",
                            "name": "丹东市",
                            "provinceId": "6"
                        },
                        {
                            "id": "45",
                            "name": "锦州市",
                            "provinceId": "6"
                        },
                        {
                            "id": "46",
                            "name": "营口市",
                            "provinceId": "6"
                        },
                        {
                            "id": "47",
                            "name": "阜新市",
                            "provinceId": "6"
                        },
                        {
                            "id": "48",
                            "name": "辽阳市",
                            "provinceId": "6"
                        },
                        {
                            "id": "49",
                            "name": "盘锦市",
                            "provinceId": "6"
                        },
                        {
                            "id": "50",
                            "name": "铁岭市",
                            "provinceId": "6"
                        },
                        {
                            "id": "51",
                            "name": "朝阳市",
                            "provinceId": "6"
                        },
                        {
                            "id": "52",
                            "name": "葫芦岛市",
                            "provinceId": "6"
                        }
                    ]
                },
                {
                    "name": "吉林",
                    "id": "7",
                    "cityList": [{
                            "id": "53",
                            "name": "长春市",
                            "provinceId": "7"
                        },
                        {
                            "id": "54",
                            "name": "吉林市",
                            "provinceId": "7"
                        },
                        {
                            "id": "55",
                            "name": "四平市",
                            "provinceId": "7"
                        },
                        {
                            "id": "56",
                            "name": "辽源市",
                            "provinceId": "7"
                        },
                        {
                            "id": "57",
                            "name": "通化市",
                            "provinceId": "7"
                        },
                        {
                            "id": "58",
                            "name": "白山市",
                            "provinceId": "7"
                        },
                        {
                            "id": "59",
                            "name": "松原市",
                            "provinceId": "7"
                        },
                        {
                            "id": "60",
                            "name": "白城市",
                            "provinceId": "7"
                        },
                        {
                            "id": "61",
                            "name": "延边朝鲜族自治州",
                            "provinceId": "7"
                        }
                    ]
                },
                {
                    "name": "黑龙江",
                    "id": "8",
                    "cityList": [{
                            "id": "62",
                            "name": "哈尔滨市",
                            "provinceId": "8"
                        },
                        {
                            "id": "63",
                            "name": "齐齐哈尔市",
                            "provinceId": "8"
                        },
                        {
                            "id": "64",
                            "name": "鸡西市",
                            "provinceId": "8"
                        },
                        {
                            "id": "65",
                            "name": "鹤岗市",
                            "provinceId": "8"
                        },
                        {
                            "id": "66",
                            "name": "双鸭山市",
                            "provinceId": "8"
                        },
                        {
                            "id": "67",
                            "name": "大庆市",
                            "provinceId": "8"
                        },
                        {
                            "id": "68",
                            "name": "伊春市",
                            "provinceId": "8"
                        },
                        {
                            "id": "69",
                            "name": "佳木斯市",
                            "provinceId": "8"
                        },
                        {
                            "id": "70",
                            "name": "七台河市",
                            "provinceId": "8"
                        },
                        {
                            "id": "71",
                            "name": "牡丹江市",
                            "provinceId": "8"
                        },
                        {
                            "id": "72",
                            "name": "黑河市",
                            "provinceId": "8"
                        },
                        {
                            "id": "73",
                            "name": "绥化市",
                            "provinceId": "8"
                        },
                        {
                            "id": "74",
                            "name": "大兴安岭地区",
                            "provinceId": "8"
                        }
                    ]
                },
                {
                    "name": "山西",
                    "id": "9",
                    "cityList": [{
                            "id": "16",
                            "name": "太原市",
                            "provinceId": "9"
                        },
                        {
                            "id": "17",
                            "name": "大同市",
                            "provinceId": "9"
                        },
                        {
                            "id": "18",
                            "name": "阳泉市",
                            "provinceId": "9"
                        },
                        {
                            "id": "19",
                            "name": "长治市",
                            "provinceId": "9"
                        },
                        {
                            "id": "20",
                            "name": "晋城市",
                            "provinceId": "9"
                        },
                        {
                            "id": "21",
                            "name": "朔州市",
                            "provinceId": "9"
                        },
                        {
                            "id": "22",
                            "name": "晋中市",
                            "provinceId": "9"
                        },
                        {
                            "id": "23",
                            "name": "运城市",
                            "provinceId": "9"
                        },
                        {
                            "id": "24",
                            "name": "忻州市",
                            "provinceId": "9"
                        },
                        {
                            "id": "25",
                            "name": "临汾市",
                            "provinceId": "9"
                        },
                        {
                            "id": "26",
                            "name": "吕梁市",
                            "provinceId": "9"
                        }
                    ]
                },
                {
                    "name": "江苏",
                    "id": "10",
                    "cityList": [{
                            "id": "77",
                            "name": "南京市",
                            "provinceId": "10"
                        },
                        {
                            "id": "78",
                            "name": "无锡市",
                            "provinceId": "10"
                        },
                        {
                            "id": "79",
                            "name": "徐州市",
                            "provinceId": "10"
                        },
                        {
                            "id": "80",
                            "name": "常州市",
                            "provinceId": "10"
                        },
                        {
                            "id": "81",
                            "name": "苏州市",
                            "provinceId": "10"
                        },
                        {
                            "id": "82",
                            "name": "南通市",
                            "provinceId": "10"
                        },
                        {
                            "id": "83",
                            "name": "连云港市",
                            "provinceId": "10"
                        },
                        {
                            "id": "84",
                            "name": "淮安市",
                            "provinceId": "10"
                        },
                        {
                            "id": "85",
                            "name": "盐城市",
                            "provinceId": "10"
                        },
                        {
                            "id": "86",
                            "name": "扬州市",
                            "provinceId": "10"
                        },
                        {
                            "id": "87",
                            "name": "镇江市",
                            "provinceId": "10"
                        },
                        {
                            "id": "88",
                            "name": "泰州市",
                            "provinceId": "10"
                        },
                        {
                            "id": "89",
                            "name": "宿迁市",
                            "provinceId": "10"
                        }
                    ]
                },
                {
                    "name": "浙江",
                    "id": "11",
                    "cityList": [{
                            "id": "90",
                            "name": "杭州市",
                            "provinceId": "11"
                        },
                        {
                            "id": "91",
                            "name": "宁波市",
                            "provinceId": "11"
                        },
                        {
                            "id": "92",
                            "name": "温州市",
                            "provinceId": "11"
                        },
                        {
                            "id": "93",
                            "name": "嘉兴市",
                            "provinceId": "11"
                        },
                        {
                            "id": "94",
                            "name": "湖州市",
                            "provinceId": "11"
                        },
                        {
                            "id": "95",
                            "name": "绍兴市",
                            "provinceId": "11"
                        },
                        {
                            "id": "96",
                            "name": "金华市",
                            "provinceId": "11"
                        },
                        {
                            "id": "97",
                            "name": "衢州市",
                            "provinceId": "11"
                        },
                        {
                            "id": "98",
                            "name": "舟山市",
                            "provinceId": "11"
                        },
                        {
                            "id": "99",
                            "name": "台州市",
                            "provinceId": "11"
                        },
                        {
                            "id": "100",
                            "name": "丽水市",
                            "provinceId": "11"
                        }
                    ]
                },
                {
                    "name": "安徽",
                    "id": "12",
                    "cityList": [{
                            "id": "101",
                            "name": "合肥市",
                            "provinceId": "12"
                        },
                        {
                            "id": "102",
                            "name": "芜湖市",
                            "provinceId": "12"
                        },
                        {
                            "id": "103",
                            "name": "蚌埠市",
                            "provinceId": "12"
                        },
                        {
                            "id": "104",
                            "name": "淮南市",
                            "provinceId": "12"
                        },
                        {
                            "id": "105",
                            "name": "马鞍山市",
                            "provinceId": "12"
                        },
                        {
                            "id": "106",
                            "name": "淮北市",
                            "provinceId": "12"
                        },
                        {
                            "id": "107",
                            "name": "铜陵市",
                            "provinceId": "12"
                        },
                        {
                            "id": "108",
                            "name": "安庆市",
                            "provinceId": "12"
                        },
                        {
                            "id": "109",
                            "name": "黄山市",
                            "provinceId": "12"
                        },
                        {
                            "id": "110",
                            "name": "滁州市",
                            "provinceId": "12"
                        },
                        {
                            "id": "111",
                            "name": "阜阳市",
                            "provinceId": "12"
                        },
                        {
                            "id": "112",
                            "name": "宿州市",
                            "provinceId": "12"
                        },
                        {
                            "id": "113",
                            "name": "巢湖市",
                            "provinceId": "12"
                        },
                        {
                            "id": "114",
                            "name": "六安市",
                            "provinceId": "12"
                        },
                        {
                            "id": "115",
                            "name": "亳州市",
                            "provinceId": "12"
                        },
                        {
                            "id": "116",
                            "name": "池州市",
                            "provinceId": "12"
                        },
                        {
                            "id": "117",
                            "name": "宣城市",
                            "provinceId": "12"
                        }
                    ]
                },
                {
                    "name": "福建",
                    "id": "13",
                    "cityList": [{
                            "id": "118",
                            "name": "福州市",
                            "provinceId": "13"
                        },
                        {
                            "id": "119",
                            "name": "厦门市",
                            "provinceId": "13"
                        },
                        {
                            "id": "120",
                            "name": "莆田市",
                            "provinceId": "13"
                        },
                        {
                            "id": "121",
                            "name": "三明市",
                            "provinceId": "13"
                        },
                        {
                            "id": "122",
                            "name": "泉州市",
                            "provinceId": "13"
                        },
                        {
                            "id": "123",
                            "name": "漳州市",
                            "provinceId": "13"
                        },
                        {
                            "id": "124",
                            "name": "南平市",
                            "provinceId": "13"
                        },
                        {
                            "id": "125",
                            "name": "龙岩市",
                            "provinceId": "13"
                        },
                        {
                            "id": "126",
                            "name": "宁德市",
                            "provinceId": "13"
                        }
                    ]
                },
                {
                    "name": "江西",
                    "id": "14",
                    "cityList": [{
                            "id": "127",
                            "name": "南昌市",
                            "provinceId": "14"
                        },
                        {
                            "id": "128",
                            "name": "景德镇市",
                            "provinceId": "14"
                        },
                        {
                            "id": "129",
                            "name": "萍乡市",
                            "provinceId": "14"
                        },
                        {
                            "id": "130",
                            "name": "九江市",
                            "provinceId": "14"
                        },
                        {
                            "id": "131",
                            "name": "新余市",
                            "provinceId": "14"
                        },
                        {
                            "id": "132",
                            "name": "鹰潭市",
                            "provinceId": "14"
                        },
                        {
                            "id": "133",
                            "name": "赣州市",
                            "provinceId": "14"
                        },
                        {
                            "id": "134",
                            "name": "吉安市",
                            "provinceId": "14"
                        },
                        {
                            "id": "135",
                            "name": "宜春市",
                            "provinceId": "14"
                        },
                        {
                            "id": "136",
                            "name": "抚州市",
                            "provinceId": "14"
                        },
                        {
                            "id": "137",
                            "name": "上饶市",
                            "provinceId": "14"
                        }
                    ]
                },
                {
                    "name": "山东",
                    "id": "15",
                    "cityList": [{
                            "id": "138",
                            "name": "济南市",
                            "provinceId": "15"
                        },
                        {
                            "id": "139",
                            "name": "青岛市",
                            "provinceId": "15"
                        },
                        {
                            "id": "140",
                            "name": "淄博市",
                            "provinceId": "15"
                        },
                        {
                            "id": "141",
                            "name": "枣庄市",
                            "provinceId": "15"
                        },
                        {
                            "id": "142",
                            "name": "东营市",
                            "provinceId": "15"
                        },
                        {
                            "id": "143",
                            "name": "烟台市",
                            "provinceId": "15"
                        },
                        {
                            "id": "144",
                            "name": "潍坊市",
                            "provinceId": "15"
                        },
                        {
                            "id": "145",
                            "name": "济宁市",
                            "provinceId": "15"
                        },
                        {
                            "id": "146",
                            "name": "泰安市",
                            "provinceId": "15"
                        },
                        {
                            "id": "147",
                            "name": "威海市",
                            "provinceId": "15"
                        },
                        {
                            "id": "148",
                            "name": "日照市",
                            "provinceId": "15"
                        },
                        {
                            "id": "149",
                            "name": "莱芜市",
                            "provinceId": "15"
                        },
                        {
                            "id": "150",
                            "name": "临沂市",
                            "provinceId": "15"
                        },
                        {
                            "id": "151",
                            "name": "德州市",
                            "provinceId": "15"
                        },
                        {
                            "id": "152",
                            "name": "聊城市",
                            "provinceId": "15"
                        },
                        {
                            "id": "153",
                            "name": "滨州市",
                            "provinceId": "15"
                        },
                        {
                            "id": "154",
                            "name": "荷泽市",
                            "provinceId": "15"
                        }
                    ]
                },
                {
                    "name": "河南",
                    "id": "16",
                    "cityList": [{
                            "id": "155",
                            "name": "郑州市",
                            "provinceId": "16"
                        },
                        {
                            "id": "156",
                            "name": "开封市",
                            "provinceId": "16"
                        },
                        {
                            "id": "157",
                            "name": "洛阳市",
                            "provinceId": "16"
                        },
                        {
                            "id": "158",
                            "name": "平顶山市",
                            "provinceId": "16"
                        },
                        {
                            "id": "159",
                            "name": "安阳市",
                            "provinceId": "16"
                        },
                        {
                            "id": "160",
                            "name": "鹤壁市",
                            "provinceId": "16"
                        },
                        {
                            "id": "161",
                            "name": "新乡市",
                            "provinceId": "16"
                        },
                        {
                            "id": "162",
                            "name": "焦作市",
                            "provinceId": "16"
                        },
                        {
                            "id": "163",
                            "name": "濮阳市",
                            "provinceId": "16"
                        },
                        {
                            "id": "164",
                            "name": "许昌市",
                            "provinceId": "16"
                        },
                        {
                            "id": "165",
                            "name": "漯河市",
                            "provinceId": "16"
                        },
                        {
                            "id": "166",
                            "name": "三门峡市",
                            "provinceId": "16"
                        },
                        {
                            "id": "167",
                            "name": "南阳市",
                            "provinceId": "16"
                        },
                        {
                            "id": "168",
                            "name": "商丘市",
                            "provinceId": "16"
                        },
                        {
                            "id": "169",
                            "name": "信阳市",
                            "provinceId": "16"
                        },
                        {
                            "id": "170",
                            "name": "周口市",
                            "provinceId": "16"
                        },
                        {
                            "id": "171",
                            "name": "驻马店市",
                            "provinceId": "16"
                        }
                    ]
                },
                {
                    "name": "湖北",
                    "id": "17",
                    "cityList": [{
                            "id": "172",
                            "name": "武汉市",
                            "provinceId": "17"
                        },
                        {
                            "id": "173",
                            "name": "黄石市",
                            "provinceId": "17"
                        },
                        {
                            "id": "174",
                            "name": "十堰市",
                            "provinceId": "17"
                        },
                        {
                            "id": "175",
                            "name": "宜昌市",
                            "provinceId": "17"
                        },
                        {
                            "id": "176",
                            "name": "襄樊市",
                            "provinceId": "17"
                        },
                        {
                            "id": "177",
                            "name": "鄂州市",
                            "provinceId": "17"
                        },
                        {
                            "id": "178",
                            "name": "荆门市",
                            "provinceId": "17"
                        },
                        {
                            "id": "179",
                            "name": "孝感市",
                            "provinceId": "17"
                        },
                        {
                            "id": "180",
                            "name": "荆州市",
                            "provinceId": "17"
                        },
                        {
                            "id": "181",
                            "name": "黄冈市",
                            "provinceId": "17"
                        },
                        {
                            "id": "182",
                            "name": "咸宁市",
                            "provinceId": "17"
                        },
                        {
                            "id": "183",
                            "name": "随州市",
                            "provinceId": "17"
                        },
                        {
                            "id": "184",
                            "name": "恩施土家族苗族自治州",
                            "provinceId": "17"
                        },
                        {
                            "id": "185",
                            "name": "省直辖行政单位",
                            "provinceId": "17"
                        }
                    ]
                },
                {
                    "name": "湖南",
                    "id": "18",
                    "cityList": [{
                            "id": "186",
                            "name": "长沙市",
                            "provinceId": "18"
                        },
                        {
                            "id": "187",
                            "name": "株洲市",
                            "provinceId": "18"
                        },
                        {
                            "id": "188",
                            "name": "湘潭市",
                            "provinceId": "18"
                        },
                        {
                            "id": "189",
                            "name": "衡阳市",
                            "provinceId": "18"
                        },
                        {
                            "id": "190",
                            "name": "邵阳市",
                            "provinceId": "18"
                        },
                        {
                            "id": "191",
                            "name": "岳阳市",
                            "provinceId": "18"
                        },
                        {
                            "id": "192",
                            "name": "常德市",
                            "provinceId": "18"
                        },
                        {
                            "id": "193",
                            "name": "张家界市",
                            "provinceId": "18"
                        },
                        {
                            "id": "194",
                            "name": "益阳市",
                            "provinceId": "18"
                        },
                        {
                            "id": "195",
                            "name": "郴州市",
                            "provinceId": "18"
                        },
                        {
                            "id": "196",
                            "name": "永州市",
                            "provinceId": "18"
                        },
                        {
                            "id": "197",
                            "name": "怀化市",
                            "provinceId": "18"
                        },
                        {
                            "id": "198",
                            "name": "娄底市",
                            "provinceId": "18"
                        },
                        {
                            "id": "199",
                            "name": "湘西土家族苗族自治州",
                            "provinceId": "18"
                        }
                    ]
                },
                {
                    "name": "广东",
                    "id": "19",
                    "cityList": [{
                            "id": "200",
                            "name": "广州市",
                            "provinceId": "19"
                        },
                        {
                            "id": "201",
                            "name": "韶关市",
                            "provinceId": "19"
                        },
                        {
                            "id": "202",
                            "name": "深圳市",
                            "provinceId": "19"
                        },
                        {
                            "id": "203",
                            "name": "珠海市",
                            "provinceId": "19"
                        },
                        {
                            "id": "204",
                            "name": "汕头市",
                            "provinceId": "19"
                        },
                        {
                            "id": "205",
                            "name": "佛山市",
                            "provinceId": "19"
                        },
                        {
                            "id": "206",
                            "name": "江门市",
                            "provinceId": "19"
                        },
                        {
                            "id": "207",
                            "name": "湛江市",
                            "provinceId": "19"
                        },
                        {
                            "id": "208",
                            "name": "茂名市",
                            "provinceId": "19"
                        },
                        {
                            "id": "209",
                            "name": "肇庆市",
                            "provinceId": "19"
                        },
                        {
                            "id": "210",
                            "name": "惠州市",
                            "provinceId": "19"
                        },
                        {
                            "id": "211",
                            "name": "梅州市",
                            "provinceId": "19"
                        },
                        {
                            "id": "212",
                            "name": "汕尾市",
                            "provinceId": "19"
                        },
                        {
                            "id": "213",
                            "name": "河源市",
                            "provinceId": "19"
                        },
                        {
                            "id": "214",
                            "name": "阳江市",
                            "provinceId": "19"
                        },
                        {
                            "id": "215",
                            "name": "清远市",
                            "provinceId": "19"
                        },
                        {
                            "id": "216",
                            "name": "东莞市",
                            "provinceId": "19"
                        },
                        {
                            "id": "217",
                            "name": "中山市",
                            "provinceId": "19"
                        },
                        {
                            "id": "218",
                            "name": "潮州市",
                            "provinceId": "19"
                        },
                        {
                            "id": "219",
                            "name": "揭阳市",
                            "provinceId": "19"
                        },
                        {
                            "id": "220",
                            "name": "云浮市",
                            "provinceId": "19"
                        }
                    ]
                },
                {
                    "name": "广西",
                    "id": "20",
                    "cityList": [{
                            "id": "221",
                            "name": "南宁市",
                            "provinceId": "20"
                        },
                        {
                            "id": "222",
                            "name": "柳州市",
                            "provinceId": "20"
                        },
                        {
                            "id": "223",
                            "name": "桂林市",
                            "provinceId": "20"
                        },
                        {
                            "id": "224",
                            "name": "梧州市",
                            "provinceId": "20"
                        },
                        {
                            "id": "225",
                            "name": "北海市",
                            "provinceId": "20"
                        },
                        {
                            "id": "226",
                            "name": "防城港市",
                            "provinceId": "20"
                        },
                        {
                            "id": "227",
                            "name": "钦州市",
                            "provinceId": "20"
                        },
                        {
                            "id": "228",
                            "name": "贵港市",
                            "provinceId": "20"
                        },
                        {
                            "id": "229",
                            "name": "玉林市",
                            "provinceId": "20"
                        },
                        {
                            "id": "230",
                            "name": "百色市",
                            "provinceId": "20"
                        },
                        {
                            "id": "231",
                            "name": "贺州市",
                            "provinceId": "20"
                        },
                        {
                            "id": "232",
                            "name": "河池市",
                            "provinceId": "20"
                        },
                        {
                            "id": "233",
                            "name": "来宾市",
                            "provinceId": "20"
                        },
                        {
                            "id": "234",
                            "name": "崇左市",
                            "provinceId": "20"
                        }
                    ]
                },
                {
                    "name": "海南",
                    "id": "21",
                    "cityList": [{
                            "id": "235",
                            "name": "海口市",
                            "provinceId": "21"
                        },
                        {
                            "id": "236",
                            "name": "三亚市",
                            "provinceId": "21"
                        },
                        {
                            "id": "237",
                            "name": "省直辖县级行政单位",
                            "provinceId": "21"
                        }
                    ]
                },
                {
                    "name": "重庆",
                    "id": "22",
                    "cityList": [{
                        "id": "238",
                        "name": "重庆市",
                        "provinceId": "22"
                    }]
                },
                {
                    "name": "四川",
                    "id": "23",
                    "cityList": [{
                            "id": "241",
                            "name": "成都市",
                            "provinceId": "23"
                        },
                        {
                            "id": "242",
                            "name": "自贡市",
                            "provinceId": "23"
                        },
                        {
                            "id": "243",
                            "name": "攀枝花市",
                            "provinceId": "23"
                        },
                        {
                            "id": "244",
                            "name": "泸州市",
                            "provinceId": "23"
                        },
                        {
                            "id": "245",
                            "name": "德阳市",
                            "provinceId": "23"
                        },
                        {
                            "id": "246",
                            "name": "绵阳市",
                            "provinceId": "23"
                        },
                        {
                            "id": "247",
                            "name": "广元市",
                            "provinceId": "23"
                        },
                        {
                            "id": "248",
                            "name": "遂宁市",
                            "provinceId": "23"
                        },
                        {
                            "id": "249",
                            "name": "内江市",
                            "provinceId": "23"
                        },
                        {
                            "id": "250",
                            "name": "乐山市",
                            "provinceId": "23"
                        },
                        {
                            "id": "251",
                            "name": "南充市",
                            "provinceId": "23"
                        },
                        {
                            "id": "252",
                            "name": "眉山市",
                            "provinceId": "23"
                        },
                        {
                            "id": "253",
                            "name": "宜宾市",
                            "provinceId": "23"
                        },
                        {
                            "id": "254",
                            "name": "广安市",
                            "provinceId": "23"
                        },
                        {
                            "id": "255",
                            "name": "达州市",
                            "provinceId": "23"
                        },
                        {
                            "id": "256",
                            "name": "雅安市",
                            "provinceId": "23"
                        },
                        {
                            "id": "257",
                            "name": "巴中市",
                            "provinceId": "23"
                        },
                        {
                            "id": "258",
                            "name": "资阳市",
                            "provinceId": "23"
                        },
                        {
                            "id": "259",
                            "name": "阿坝藏族羌族自治州",
                            "provinceId": "23"
                        },
                        {
                            "id": "260",
                            "name": "甘孜藏族自治州",
                            "provinceId": "23"
                        },
                        {
                            "id": "261",
                            "name": "凉山彝族自治州",
                            "provinceId": "23"
                        }
                    ]
                },
                {
                    "name": "贵州",
                    "id": "24",
                    "cityList": [{
                            "id": "262",
                            "name": "贵阳市",
                            "provinceId": "24"
                        },
                        {
                            "id": "263",
                            "name": "六盘水市",
                            "provinceId": "24"
                        },
                        {
                            "id": "264",
                            "name": "遵义市",
                            "provinceId": "24"
                        },
                        {
                            "id": "265",
                            "name": "安顺市",
                            "provinceId": "24"
                        },
                        {
                            "id": "266",
                            "name": "铜仁地区",
                            "provinceId": "24"
                        },
                        {
                            "id": "267",
                            "name": "黔西南布依族苗族自治州",
                            "provinceId": "24"
                        },
                        {
                            "id": "268",
                            "name": "毕节地区",
                            "provinceId": "24"
                        },
                        {
                            "id": "269",
                            "name": "黔东南苗族侗族自治州",
                            "provinceId": "24"
                        },
                        {
                            "id": "270",
                            "name": "黔南布依族苗族自治州",
                            "provinceId": "24"
                        }
                    ]
                },
                {
                    "name": "云南",
                    "id": "25",
                    "cityList": [{
                            "id": "271",
                            "name": "昆明市",
                            "provinceId": "25"
                        },
                        {
                            "id": "272",
                            "name": "曲靖市",
                            "provinceId": "25"
                        },
                        {
                            "id": "273",
                            "name": "玉溪市",
                            "provinceId": "25"
                        },
                        {
                            "id": "274",
                            "name": "保山市",
                            "provinceId": "25"
                        },
                        {
                            "id": "275",
                            "name": "昭通市",
                            "provinceId": "25"
                        },
                        {
                            "id": "276",
                            "name": "丽江市",
                            "provinceId": "25"
                        },
                        {
                            "id": "277",
                            "name": "思茅市",
                            "provinceId": "25"
                        },
                        {
                            "id": "278",
                            "name": "临沧市",
                            "provinceId": "25"
                        },
                        {
                            "id": "279",
                            "name": "楚雄彝族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "280",
                            "name": "红河哈尼族彝族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "281",
                            "name": "文山壮族苗族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "282",
                            "name": "西双版纳傣族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "283",
                            "name": "大理白族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "284",
                            "name": "德宏傣族景颇族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "285",
                            "name": "怒江傈僳族自治州",
                            "provinceId": "25"
                        },
                        {
                            "id": "286",
                            "name": "迪庆藏族自治州",
                            "provinceId": "25"
                        }
                    ]
                },
                {
                    "name": "西藏",
                    "id": "26",
                    "cityList": [{
                            "id": "287",
                            "name": "拉萨市",
                            "provinceId": "26"
                        },
                        {
                            "id": "288",
                            "name": "昌都地区",
                            "provinceId": "26"
                        },
                        {
                            "id": "289",
                            "name": "山南地区",
                            "provinceId": "26"
                        },
                        {
                            "id": "290",
                            "name": "日喀则地区",
                            "provinceId": "26"
                        },
                        {
                            "id": "291",
                            "name": "那曲地区",
                            "provinceId": "26"
                        },
                        {
                            "id": "292",
                            "name": "阿里地区",
                            "provinceId": "26"
                        },
                        {
                            "id": "293",
                            "name": "林芝地区",
                            "provinceId": "26"
                        }
                    ]
                },
                {
                    "name": "陕西",
                    "id": "27",
                    "cityList": [{
                            "id": "294",
                            "name": "西安市",
                            "provinceId": "27"
                        },
                        {
                            "id": "295",
                            "name": "铜川市",
                            "provinceId": "27"
                        },
                        {
                            "id": "296",
                            "name": "宝鸡市",
                            "provinceId": "27"
                        },
                        {
                            "id": "297",
                            "name": "咸阳市",
                            "provinceId": "27"
                        },
                        {
                            "id": "298",
                            "name": "渭南市",
                            "provinceId": "27"
                        },
                        {
                            "id": "299",
                            "name": "延安市",
                            "provinceId": "27"
                        },
                        {
                            "id": "300",
                            "name": "汉中市",
                            "provinceId": "27"
                        },
                        {
                            "id": "301",
                            "name": "榆林市",
                            "provinceId": "27"
                        },
                        {
                            "id": "302",
                            "name": "安康市",
                            "provinceId": "27"
                        },
                        {
                            "id": "303",
                            "name": "商洛市",
                            "provinceId": "27"
                        }
                    ]
                },
                {
                    "name": "甘肃",
                    "id": "28",
                    "cityList": [{
                            "id": "304",
                            "name": "兰州市",
                            "provinceId": "28"
                        },
                        {
                            "id": "305",
                            "name": "嘉峪关市",
                            "provinceId": "28"
                        },
                        {
                            "id": "306",
                            "name": "金昌市",
                            "provinceId": "28"
                        },
                        {
                            "id": "307",
                            "name": "白银市",
                            "provinceId": "28"
                        },
                        {
                            "id": "308",
                            "name": "天水市",
                            "provinceId": "28"
                        },
                        {
                            "id": "309",
                            "name": "武威市",
                            "provinceId": "28"
                        },
                        {
                            "id": "310",
                            "name": "张掖市",
                            "provinceId": "28"
                        },
                        {
                            "id": "311",
                            "name": "平凉市",
                            "provinceId": "28"
                        },
                        {
                            "id": "312",
                            "name": "酒泉市",
                            "provinceId": "28"
                        },
                        {
                            "id": "313",
                            "name": "庆阳市",
                            "provinceId": "28"
                        },
                        {
                            "id": "314",
                            "name": "定西市",
                            "provinceId": "28"
                        },
                        {
                            "id": "315",
                            "name": "陇南市",
                            "provinceId": "28"
                        },
                        {
                            "id": "316",
                            "name": "临夏回族自治州",
                            "provinceId": "28"
                        },
                        {
                            "id": "317",
                            "name": "甘南藏族自治州",
                            "provinceId": "28"
                        }
                    ]
                },
                {
                    "name": "青海",
                    "id": "29",
                    "cityList": [{
                            "id": "318",
                            "name": "西宁市",
                            "provinceId": "29"
                        },
                        {
                            "id": "319",
                            "name": "海东地区",
                            "provinceId": "29"
                        },
                        {
                            "id": "320",
                            "name": "海北藏族自治州",
                            "provinceId": "29"
                        },
                        {
                            "id": "321",
                            "name": "黄南藏族自治州",
                            "provinceId": "29"
                        },
                        {
                            "id": "322",
                            "name": "海南藏族自治州",
                            "provinceId": "29"
                        },
                        {
                            "id": "323",
                            "name": "果洛藏族自治州",
                            "provinceId": "29"
                        },
                        {
                            "id": "324",
                            "name": "玉树藏族自治州",
                            "provinceId": "29"
                        },
                        {
                            "id": "325",
                            "name": "海西蒙古族藏族自治州",
                            "provinceId": "29"
                        }
                    ]
                },
                {
                    "name": "宁夏",
                    "id": "30",
                    "cityList": [{
                            "id": "326",
                            "name": "银川市",
                            "provinceId": "30"
                        },
                        {
                            "id": "327",
                            "name": "石嘴山市",
                            "provinceId": "30"
                        },
                        {
                            "id": "328",
                            "name": "吴忠市",
                            "provinceId": "30"
                        },
                        {
                            "id": "329",
                            "name": "固原市",
                            "provinceId": "30"
                        },
                        {
                            "id": "330",
                            "name": "中卫市",
                            "provinceId": "30"
                        }
                    ]
                },
                {
                    "name": "新疆",
                    "id": "31",
                    "cityList": [{
                            "id": "331",
                            "name": "乌鲁木齐市",
                            "provinceId": "31"
                        },
                        {
                            "id": "332",
                            "name": "克拉玛依市",
                            "provinceId": "31"
                        },
                        {
                            "id": "333",
                            "name": "吐鲁番地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "334",
                            "name": "哈密地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "335",
                            "name": "昌吉回族自治州",
                            "provinceId": "31"
                        },
                        {
                            "id": "336",
                            "name": "博尔塔拉蒙古自治州",
                            "provinceId": "31"
                        },
                        {
                            "id": "337",
                            "name": "巴音郭楞蒙古自治州",
                            "provinceId": "31"
                        },
                        {
                            "id": "338",
                            "name": "阿克苏地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "339",
                            "name": "克孜勒苏柯尔克孜自治州",
                            "provinceId": "31"
                        },
                        {
                            "id": "340",
                            "name": "喀什地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "341",
                            "name": "和田地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "342",
                            "name": "伊犁哈萨克自治州",
                            "provinceId": "31"
                        },
                        {
                            "id": "343",
                            "name": "塔城地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "344",
                            "name": "阿勒泰地区",
                            "provinceId": "31"
                        },
                        {
                            "id": "345",
                            "name": "省直辖行政单位",
                            "provinceId": "31"
                        }
                    ]
                },
                {
                    "name": "台湾",
                    "id": "32",
                    "cityList": [{
                            "id": "348",
                            "name": "台北",
                            "provinceId": "32"
                        },
                        {
                            "id": "349",
                            "name": "高雄",
                            "provinceId": "32"
                        },
                        {
                            "id": "350",
                            "name": "基隆",
                            "provinceId": "32"
                        },
                        {
                            "id": "351",
                            "name": "台中",
                            "provinceId": "32"
                        },
                        {
                            "id": "352",
                            "name": "台南",
                            "provinceId": "32"
                        },
                        {
                            "id": "353",
                            "name": "新竹",
                            "provinceId": "32"
                        },
                        {
                            "id": "354",
                            "name": "嘉义",
                            "provinceId": "32"
                        },
                        {
                            "id": "355",
                            "name": "台北县",
                            "provinceId": "32"
                        },
                        {
                            "id": "356",
                            "name": "宜兰县",
                            "provinceId": "32"
                        },
                        {
                            "id": "357",
                            "name": "桃园县",
                            "provinceId": "32"
                        },
                        {
                            "id": "358",
                            "name": "新竹县",
                            "provinceId": "32"
                        },
                        {
                            "id": "359",
                            "name": "苗栗县",
                            "provinceId": "32"
                        },
                        {
                            "id": "360",
                            "name": "台中县",
                            "provinceId": "32"
                        },
                        {
                            "id": "361",
                            "name": "彰化县",
                            "provinceId": "32"
                        },
                        {
                            "id": "362",
                            "name": "南投县",
                            "provinceId": "32"
                        },
                        {
                            "id": "363",
                            "name": "云林县",
                            "provinceId": "32"
                        },
                        {
                            "id": "364",
                            "name": "嘉义县",
                            "provinceId": "32"
                        },
                        {
                            "id": "365",
                            "name": "台南县",
                            "provinceId": "32"
                        },
                        {
                            "id": "366",
                            "name": "高雄县",
                            "provinceId": "32"
                        },
                        {
                            "id": "367",
                            "name": "屏东县",
                            "provinceId": "32"
                        },
                        {
                            "id": "368",
                            "name": "台东县",
                            "provinceId": "32"
                        },
                        {
                            "id": "369",
                            "name": "花莲县",
                            "provinceId": "32"
                        },
                        {
                            "id": "370",
                            "name": "澎湖县",
                            "provinceId": "32"
                        }
                    ]
                },
                {
                    "name": "香港",
                    "id": "33",
                    "cityList": [{
                        "id": "346",
                        "name": "香港",
                        "provinceId": "33"
                    }]
                },
                {
                    "name": "澳门",
                    "id": "34",
                    "cityList": [{
                        "id": "347",
                        "name": "澳门",
                        "provinceId": "34"
                    }]
                }
            ]
        },
        "type": "JSONDoctor"
    });
};
module.exports = data;