var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "type": "修改医生状态"
    })
}
module.exports = data;