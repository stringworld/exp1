var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [{"name": "全科医生", "value": "1"}, {"name": "妇科医生", "value": "2"}, {
            "name": "儿保医生",
            "value": "3"
        }, {"name": "专科医生", "value": "4"}, {"name": "全科护士", "value": "5"}, {"name": "专科护士", "value": "6"}]
    });
};
module.exports = data;