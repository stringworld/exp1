var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "data": {
            "tagList": [{
                    "count": "20",
                    "tagName": "高血压",
                    "disable": true
                },
                {
                    "count": "20",
                    "tagName": "糖尿病糖尿病",
                    "disable": false
                },
                {
                    "count": "20",
                    "tagName": "心脏病",
                    "disable": true
                },
                {
                    "count": "20",
                    "tagName": "高脂血症高脂血症高脂血症",
                    "disable": false
                },
                {
                    "count": "20",
                    "tagName": "冠心病",
                    "disable": true
                }
            ]
        },
        "isSuccess": true,
        "type": "JSONPatient"
    })
}
module.exports = data;