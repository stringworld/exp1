var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "code": 0,
        "data": {
            "systemTags": [
                "全部",
                "已签约",
                "已关注",
                "VIP",
                "潜力",
                "一般",
                "黑名单",
                "高血压",
                "糖尿病",
                "高脂血症",
                "脑卒中",
                "冠心病",
                "骨质疏松",
                "痛风",
                "慢阻肺",
                "骨关节炎",
                "肿瘤康复",
                "前列腺增生",
                "慢性肝炎",
                "失眠症",
                "抑郁与焦虑",
                "老慢支"
            ],
            "usedTags": [{
                    "type": "my",
                    "typeName": "自定义",
                    "input": "checkbox",
                    "icon": "http://upyun.thedoc.cn/img/3132325c-7e75-4253-9a79-c55df2b0b297.png",
                    "router": "router://labelWebView?url=http%3A%2F%2F192.168.10.36%3A8080%2Fprm.html%23%2FdelLabel",
                    "tagList": [{
                            "tag": "aaaa",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "Hdhdhd",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "悲喜",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "巨人症1",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "脑出血",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "大概很丰富",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "老衲",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "b x j j z b",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "b x j j z b z b b",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "大蒜味",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "好风光",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "糖尿病医院",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "心脏病123",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "肠道感染",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "听音乐",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "帕金森",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "1234565567",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "阻塞性肺气肿",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "哦",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "心脏病",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "脑中风",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "高血压1",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "老年痴呆",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "肺炎",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "高血压一",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "失能1",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "测试1",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "高血脂",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "我得测试",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "在线",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "鱼缸",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "hi ki糖尿病",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "支气管哮喘",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "绝对经典",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "风风光",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "脑梗塞",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "123456",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "543",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "悲喜交加在包治百病b",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "冀磊",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "Hdiidid bbbbbbbb",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "h f h j",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "123456556",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": " 测试1 ",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "[高血压",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "测试1 ]",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "[\"黑名单\"]",
                            "type": "my",
                            "selected": false
                        },
                        {
                            "tag": "天下",
                            "type": "my",
                            "selected": true
                        },
                        {
                            "tag": "test",
                            "type": "my",
                            "selected": false
                        }
                    ]
                },
                {
                    "type": "disease",
                    "typeName": "病种类型",
                    "input": "checkbox",
                    "tagList": [{
                            "tag": "高血压",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "糖尿病",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "高脂血症",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "脑卒中",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "冠心病",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "骨质疏松",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "痛风",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "慢阻肺",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "骨关节炎",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "肿瘤康复",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "前列腺增生",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "慢性肝炎",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "失眠症",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "抑郁与焦虑",
                            "type": "disease",
                            "selected": false
                        },
                        {
                            "tag": "老慢支",
                            "type": "disease",
                            "selected": false
                        }
                    ]
                },
                {
                    "type": "level",
                    "typeName": "患者级别",
                    "input": "radio",
                    "tagList": [{
                        "tag": "黑名单",
                        "type": "level",
                        "selected": false
                    }]
                }
            ]
        }
    })
}
module.exports = data;