var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [{
            "menuList": null,
            "price": {"amount": 500.0},
            "name": "上门基本服务",
            "id": "4"
        },
            {
                "menuList": [{
                    "id": "16",
                    "parentId": "5",
                    "name": "静脉输液",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "serviceProvider": "1",
                    "level": "3",
                    "status": "1",
                    "required": true,
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "17",
                        "parentId": "5",
                        "name": "肌肉注射",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "serviceProvider": "1",
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "输液",
                "id": "5"
            },
            {
                "menuList": [{
                    "id": "18",
                    "parentId": "6",
                    "name": "术后小换药",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "serviceProvider": "3",
                    "level": "3",
                    "status": "1",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "19",
                        "parentId": "6",
                        "name": "术后中换药",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "serviceProvider": "3",
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "换药拆线",
                "id": "6"
            },
            {
                "menuList": [{
                    "id": "20",
                    "parentId": "7",
                    "name": "抽血",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "level": "3",
                    "status": "1",
                    "groupName": "抽血",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "21",
                        "parentId": "7",
                        "name": "尿检",
                        "groupName": "尿检",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "检验",
                "id": "7"
            },
            {
                "menuList": [{
                    "id": "22",
                    "parentId": "8",
                    "name": "常规引流管",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "level": "3",
                    "status": "1",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                }],
                "price": {"amount": 500.0},
                "name": "换管",
                "id": "8"
            },
            {
                "menuList": [{
                    "id": "23",
                    "parentId": "9",
                    "name": "问诊",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "level": "3",
                    "status": "1",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "24",
                        "parentId": "9",
                        "name": "体格检查",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    },
                    {
                        "id": "25",
                        "parentId": "9",
                        "name": "病情分析",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "儿科",
                "id": "9"
            },
            {
                "menuList": [{
                    "id": "26",
                    "parentId": "10",
                    "name": "望闻问切",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "level": "3",
                    "status": "1",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "27",
                        "parentId": "10",
                        "name": "推拿按摩",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    },
                    {
                        "id": "28",
                        "parentId": "10",
                        "name": "针灸拔罐",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "中医",
                "id": "10"
            },
            {
                "menuList": [{
                    "id": "29",
                    "parentId": "11",
                    "name": "运动康复",
                    "price": {"amount": 500.0},
                    "checked": false,
                    "level": "3",
                    "status": "1",
                    "logoPath": "http://192.168.10.215/images/footer_logo.png",
                    "serviceMessage": "为患者提供精准的上门服务"
                },
                    {
                        "id": "30",
                        "parentId": "11",
                        "name": "理疗",
                        "price": {"amount": 500.0},
                        "checked": false,
                        "level": "3",
                        "status": "1",
                        "logoPath": "http://192.168.10.215/images/footer_logo.png",
                        "serviceMessage": "为患者提供精准的上门服务"
                    }],
                "price": {"amount": 500.0},
                "name": "家床康复",
                "id": "11"
            }]
    });
};
module.exports = data;