
# Helper for a test_reflect test

__import__('idonotexist')
